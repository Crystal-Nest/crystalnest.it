package crystalnest.cobweb_mod_template;

/**
 * Common mod loader.
 */
public class CommonModLoader {
  /**
   * Initialize operations common across loaders.
   */
  public static void init() {}
}
